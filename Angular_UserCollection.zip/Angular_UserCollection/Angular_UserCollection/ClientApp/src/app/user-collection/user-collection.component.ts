import { Component, Inject } from '@angular/core';


@Component({
  selector: 'app-user-collection',
  templateUrl: './user-collection.component.html'
})


export class UserCollectionComponent {
  value = 'Clear me';
}

export class MatDatepickerModule {
  minDate = new Date(2000, 0, 1);
  maxDate = new Date(2020, 0, 1);
}


